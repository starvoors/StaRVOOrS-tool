package java.lang.annotation;

/**
 * @generated
 */
public interface Annotation {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public abstract java.lang.Class annotationType();
}