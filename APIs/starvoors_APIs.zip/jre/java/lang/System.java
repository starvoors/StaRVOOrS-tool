package java.lang;

/**
 * @generated
 */
public final class System extends java.lang.Object {
   /**
    * @generated
    */
   public static final java.io.PrintStream err;
}