package java.lang;

/**
 * @generated
 */
public class NumberFormatException extends java.lang.IllegalArgumentException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public NumberFormatException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public NumberFormatException(java.lang.String param0);
}