package java.lang;

/**
 * @generated
 */
public interface AutoCloseable {
}