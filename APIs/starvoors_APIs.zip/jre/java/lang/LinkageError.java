package java.lang;

/**
 * @generated
 */
public class LinkageError extends java.lang.Error {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public LinkageError();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public LinkageError(java.lang.String param0);
}