package java.lang;

/**
 * @generated
 */
public class Thread extends java.lang.Object implements java.lang.Runnable {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public Thread();
}