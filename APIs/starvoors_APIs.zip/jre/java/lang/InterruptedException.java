package java.lang;

/**
 * @generated
 */
public class InterruptedException extends java.lang.Exception {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public InterruptedException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public InterruptedException(java.lang.String param0);
}