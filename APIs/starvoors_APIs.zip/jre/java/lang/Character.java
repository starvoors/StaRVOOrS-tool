package java.lang;

/**
 * @generated
 */
public final class Character extends java.lang.Object implements java.io.Serializable, java.lang.Comparable {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public static int digit(char param0, int param1);
}