package java.lang;

/**
 * @generated
 */
public class NegativeArraySizeException extends java.lang.RuntimeException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public NegativeArraySizeException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public NegativeArraySizeException(java.lang.String param0);
}